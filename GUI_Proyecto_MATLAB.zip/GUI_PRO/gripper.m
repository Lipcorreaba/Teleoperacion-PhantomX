function gripper(modo)
    PosPub5=rospublisher('/Phantom_sim/joint5_position_controller/command',...
    'std_msgs/Float64');
    PosPub6=rospublisher('/Phantom_sim/joint6_position_controller/command',...
    'std_msgs/Float64');
    Posmsg5=rosmessage(PosPub5);
    Posmsg6=rosmessage(PosPub6); 
    if modo=="cerrar"
        Posmsg5.Data=1.5;
        Posmsg6.Data=1.5;
    else
        if modo=="abrir"
            Posmsg5.Data=3;
            Posmsg6.Data=3;
        end
    end
    send(PosPub5,Posmsg5)
    send(PosPub6,Posmsg6)
end
