function subscriptor(Q)
    sub=rossubscriber('/Phantom_sim/joint_states');
    msg=receive(sub);
    Pos=msg.Position';
    errorR=Q(1:4)-Pos(3:6);
    errorG=Q(5:6)-Pos(1:2);
    disp("Error en cada junta: ")
    disp("Junta 1: " + errorR(1) + " rad")
    disp("Junta 2: " + errorR(2) + " rad")
    disp("Junta 3: " + errorR(3) + " rad")
    disp("Junta 4: " + errorR(4) + " rad")
    disp("Finger 1: " + errorG(1) + " mm")
    disp("Finger 2: " + errorG(2) + " mm")
end
