function varargout = ProyectoGUI(varargin)
% PROYECTOGUI MATLAB code for ProyectoGUI.fig
%      PROYECTOGUI, by itself, creates a new PROYECTOGUI or raises the existing
%      singleton*.
%
%      H = PROYECTOGUI returns the handle to a new PROYECTOGUI or the handle to
%      the existing singleton*.
%
%      PROYECTOGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROYECTOGUI.M with the given input arguments.
%
%      PROYECTOGUI('Property','Value',...) creates a new PROYECTOGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ProyectoGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ProyectoGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ProyectoGUI

% Last Modified by GUIDE v2.5 19-Jun-2020 17:35:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ProyectoGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ProyectoGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ProyectoGUI is made visible.
function ProyectoGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ProyectoGUI (see VARARGIN)

% Choose default command line output for ProyectoGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
rosinit('192.168.1.20')
global Phantom Posicion P_home Q_home Stop Cam
Phantom=phantom(0,0,0,0);
publicador([0 0 0 0])
Q_home=[0 0 0 0];
MTH_home=Phantom.fkine(Q_home);
R=tr2rpy(MTH_home);
P_home=[MTH_home.t',R];
Posicion=P_home;
Q_home=[0 1.57 0 0];
publicador(Q_home)
MTH_home=Phantom.fkine(Q_home);
R=tr2rpy(MTH_home);
P_home=[MTH_home.t',R];
Posicion=P_home;
Stop=0;
Cam=handles.camara;
% axes(Cam)
% sub=rossubscriber('/Phantom_sim/camera1/image_raw/compressed');
% img=sub.LatestMessage.readImage;
% image(img)


% UIWAIT makes ProyectoGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ProyectoGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in modo.
function modo_Callback(hObject, eventdata, handles)
% hObject    handle to modo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns modo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from modo


% --- Executes during object creation, after setting all properties.
function modo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)

global Phantom Posicion Stop

set(handles.estado,'String','Ocupado');
set(handles.estado,'ForegroundColor',[1 0 0]);
modo=get(handles.modo,'Value')
trayectoria=get(handles.trayectoria,'Value')
switch modo
    case 1
       Posicion=manual(Phantom,Posicion,handles.x,handles.y,handles.z,handles.roll,handles.pitch,handles.yaw,handles.configuraciones);
    case 2    
       auto(Phantom,trayectoria,handles.x,handles.y,handles.z,handles.roll,handles.pitch,handles.yaw,handles.configuraciones)
end
set(handles.estado,'String','En espera.');
set(handles.estado,'ForegroundColor',[0 1 0]);

% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of start


% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
global Stop
Stop=1;

% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of stop


% --- Executes on selection change in trayectoria.
function trayectoria_Callback(hObject, eventdata, handles)
% hObject    handle to trayectoria (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns trayectoria contents as cell array
%        contents{get(hObject,'Value')} returns selected item from trayectoria


% --- Executes during object creation, after setting all properties.
function trayectoria_CreateFcn(hObject, eventdata, handles)
% hObject    handle to trayectoria (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gh.
function gh_Callback(hObject, eventdata, handles)
global Posicion Phantom Stop P_home
set(handles.estado,'String','Ocupado');
set(handles.estado,'ForegroundColor',[1 0 0]);
Stop=0;

T=Posicion(1:3)';
R=rpy2r(Posicion(4:6));
MTHi=rt2tr(R,T);
MTHf=Phantom.fkine([0 1.57 0 0]);
mover_phantom(MTHi,MTHf,3,Phantom,handles.x,handles.y,handles.z,handles.roll,handles.pitch,handles.yaw,handles.configuraciones)
Posicion=P_home;
set(handles.estado,'String','En espera.');
set(handles.estado,'ForegroundColor',[0 1 0]);
% hObject    handle to gh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gh
