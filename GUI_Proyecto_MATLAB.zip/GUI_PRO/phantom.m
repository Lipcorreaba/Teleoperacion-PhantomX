function Robot=phantom(q1,q2,q3,q4)
    L1= Link('revolute','alpha',0,'a',0,'d',137,'offset',q1,'qlim',[-5*pi/6 5*pi/6],'modified'); % Link 1
    L2= Link('revolute','alpha',pi/2,'a',0,'d',0,'offset',q2,'qlim',[-pi/2 pi/2],'modified'); % Link 2
    L3= Link('revolute','alpha',0,'a',105,'d',0,'offset',q3,'qlim',[-90 90]*pi/180,'modified'); % Link 3
    L4= Link('revolute','alpha',0,'a',105,'d',0,'offset',q4, 'qlim',[-90 90]*pi/180,'modified'); % Link 4

    Robot=SerialLink([L1,L2,L3,L4]','name','R3gdl');
    Robot.tool=transl(110,0,0);
end