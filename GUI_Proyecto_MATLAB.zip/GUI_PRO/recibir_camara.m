function image=recibir_camara()
   sub=rossubscriber('/Phantom_sim/camera1/image_raw/compressed');
   image=sub.LatestMessage.readImage;
end
   