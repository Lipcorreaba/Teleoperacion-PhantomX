function Elevate(Pi_el,Pf_el,Robot,puntos,x,y,z,r,p,ya,con)
    Ti_el=Pi_el(1:3)';
    Ri_el=rpy2r(Pi_el(4:6));
    MTHi_el=rt2tr(Ri_el,Ti_el);
    Tf_el=Pf_el(1:3)';
    Rf_el=rpy2r(Pf_el(4:6));
    MTHf_el=rt2tr(Rf_el,Tf_el);
    mover_phantom(MTHi_el,MTHf_el,puntos,Robot,x,y,z,r,p,ya,con)
end