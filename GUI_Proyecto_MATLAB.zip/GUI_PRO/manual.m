function posicion=manual(Robot,posicion,hx,hy,hz,hr,hp,hya,con)
global Stop
joy=vrjoystick(3);

    while Stop==0
        posicionini=posicion
        ri=rpy2r(posicionini(4:6));
        di=posicionini(1:3);
        MTHi=rt2tr(ri,di);

        x=axis(joy, 1)*20;
        y=axis(joy, 2)*-20;
        z=axis(joy, 4)*20;
        p=axis(joy, 8)*-10*pi/180;
        g_open=button(joy,3);
        g_close=button(joy,1);
        if g_open==1
            gripper('abrir')
        elseif g_close==1
            gripper('cerrar')
        end
        posicion(1:3)=posicion(1:3)+[x,y,z];
        posicion(5)=posicion(5)+p;
        rf=rpy2r(posicion(4:6));
        df=posicion(1:3);
        MTHf=rt2tr(rf,df);
        posicion=  mover(MTHi,MTHf,1,Robot,hx,hy,hz,hr,hp,hya,con);
        pause(0.2)
    end
return 
end


