function trayectorias=auto(Phantom,n,x,y,z,r,p,ya,con) 

Q_home=[0 1.57 0 0];
Posicion=[0.2548 0 457 1.57 0 1.57];
set(x,'String',string(Posicion(1)))
set(y,'String',string(Posicion(2)))
set(z,'String',string(Posicion(3)))
set(r,'String',string(Posicion(4)))
set(p,'String',string(Posicion(5)))
set(ya,'String',string(Posicion(6)))
Q=round(Q_home*180/pi,3);
set(con,'String','['+string(vpa(Q(1),3))+' '+string(vpa(Q(2),3))+' '+string(vpa(Q(3),3))+' '+string(vpa(Q(4),3))+']');
switch n
    case 1
        P_ap=[0 180 100 0 1.57 0];
        Approach(Q_home,P_ap,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_pi=[0 180 10 0 1.57 0];
        Pick(P_ap,P_pi,Phantom,3,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_el=[0 180 200 0 1.57 0];
        Elevate(P_ap,P_el,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_el;
        P_tr=[180 0 100 0 1.57 -1.57];
        Transport(P_el,P_tr,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_tr;
        P_pl=[180 0 10 0 1.57 -1.57];
        Place(P_tr,P_pl,Phantom,3,x,y,z,r,p,ya,con)
        Posicion=P_tr;
        T=Posicion(1:3)';
        R=rpy2r(Posicion(4:6));
        MTHi=rt2tr(R,T);
        MTHf=Phantom.fkine(Q_home);
        mover_phantom(MTHi,MTHf,7,Phantom,x,y,z,r,p,ya,con)
        Posicion=Q_home;
    case 2 
        P_ap=[0 180 100 0 1.57 0];
        Approach(Q_home,P_ap,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_pi=[0 180 10 0 1.57 0];
        Pick(P_ap,P_pi,Phantom,3,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_el=[0 180 200 0 1.57 0];
        Elevate(P_ap,P_el,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_el;
        P_tr=[0 -180 100 1.57 1.57 -1.57];
        Transport(P_el,P_tr,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_tr;
        P_pl=[0 -180 10 1.57 1.57 -1.57];
        Place(P_tr,P_pl,Phantom,4,x,y,z,r,p,ya,con)
        Posicion=P_tr;
        T=Posicion(1:3)';
        R=rpy2r(Posicion(4:6));
        MTHi=rt2tr(R,T);
        MTHf=Phantom.fkine(Q_home);
        mover_phantom(MTHi,MTHf,7,Phantom,x,y,z,r,p,ya,con)
        Posicion=Q_home;
     case 3
        P_ap=[0 180 100 0 1.57 0];
        Approach(Q_home,P_ap,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_pi=[0 180 10 0 1.57 0];
        Pick(P_ap,P_pi,Phantom,3,x,y,z,r,p,ya,con)
        Posicion=P_ap;
        P_el=[0 180 200 0 1.57 0];
        Elevate(P_ap,P_el,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_el;
        P_tr=[-160 -100 100 1.57 1.3 -2.618];
        Transport(P_el,P_tr,Phantom,7,x,y,z,r,p,ya,con)
        Posicion=P_tr;
        P_pl=[-160 -100 10 1.57 1.3 -2.618];
        Place(P_tr,P_pl,Phantom,3,x,y,z,r,p,ya,con)
        Posicion=P_tr; 
        T=Posicion(1:3)';
        R=rpy2r(Posicion(4:6));
        MTHi=rt2tr(R,T);
        MTHf=Phantom.fkine(Q_home);
        mover_phantom(MTHi,MTHf,7,Phantom,x,y,z,r,p,ya,con)
        Posicion=Q_home;
end