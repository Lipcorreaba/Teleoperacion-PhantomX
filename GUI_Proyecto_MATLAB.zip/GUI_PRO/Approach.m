function Approach(Home,P_ap,Robot,puntos,x,y,z,r,p,ya,con)
    Home
    MTHi_ap=Robot.fkine(Home);
    T_ap=P_ap(1:3)';
    R_ap=rpy2r(P_ap(4:6));
    MTHf_ap=rt2tr(R_ap,T_ap);
    mover_phantom(MTHi_ap,MTHf_ap,puntos,Robot,x,y,z,r,p,ya,con);
end