function Pick(Pi_pi,Pf_pi,Robot,puntos,x,y,z,r,p,ya,con)
    Ti_pi=Pi_pi(1:3)';
    Ri_pi=rpy2r(Pi_pi(4:6));
    MTHi_pi=rt2tr(Ri_pi,Ti_pi);
    Tf_pi=Pf_pi(1:3)';
    Rf_pi=rpy2r(Pf_pi(4:6));
    MTHf_pi=rt2tr(Rf_pi,Tf_pi);
    pp_phantom(MTHi_pi,MTHf_pi,puntos,Robot,x,y,z,r,p,ya,con)
    pause(0.5)
    gripper('cerrar')
    pause(0.5)
    pp_phantom(MTHf_pi,MTHi_pi,puntos,Robot,x,y,z,r,p,ya,con)
end