function mover_phantom(MTHi,MTHf,puntos,Robot,x,y,z,r,p,ya,con)
    global Stop Cam
    Qi=Robot.ikcon(MTHi);
    Qf=Robot.ikcon(MTHf);
    paso=(Qf-Qi)/(puntos);
    Q=Qi;
    i=0;
    %axes(Cam)
    while (Stop==0 && i<=puntos)
        publicador(Q)
        pause(0.7)
        t=Robot.fkine(Q);
        Qg=round(Q*180/pi,3);
        set(con,'String','['+string(vpa(Qg(1),3))+' '+string(vpa(Qg(2),3))+' '+string(vpa(Qg(3),3))+' '+string(vpa(Qg(4),3))+']');
        Posicion=round([t.t',tr2rpy(t)],3);
        set(x,'String',string(vpa(Posicion(1),3)));
        set(y,'String',string(vpa(Posicion(2),3)));
        set(z,'String',string(vpa(Posicion(3),3)));
        set(r,'String',string(vpa(Posicion(4),3)));
        set(p,'String',string(vpa(Posicion(5),3)));
        set(ya,'String',string(vpa(Posicion(6),3)));
%         sub=rossubscriber('/Phantom_sim/camera1/image_raw/compressed');
%         img=sub.LatestMessage.readImage;
%         image(img)
        Q=Q+paso;
        %pause(0.5)
        i=i+1;
    end    
end

