function Transport(Pi_tr,Pf_tr,Robot,puntos,x,y,z,r,p,ya,con)
    Ti_tr=Pi_tr(1:3)';
    Ri_tr=rpy2r(Pi_tr(4:6));
    MTHi_tr=rt2tr(Ri_tr,Ti_tr);
    Tf_tr=Pf_tr(1:3)';
    Rf_tr=rpy2r(Pf_tr(4:6));
    MTHf_tr=rt2tr(Rf_tr,Tf_tr);
    mover_phantom(MTHi_tr,MTHf_tr,puntos,Robot,x,y,z,r,p,ya,con)
end