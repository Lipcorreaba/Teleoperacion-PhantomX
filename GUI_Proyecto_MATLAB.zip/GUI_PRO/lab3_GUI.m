function varargout = lab3_GUI(varargin)
% LAB3_GUI MATLAB code for lab3_GUI.fig
%      LAB3_GUI, by itself, creates a new LAB3_GUI or raises the existing
%      singleton*.
%
%      H = LAB3_GUI returns the handle to a new LAB3_GUI or the handle to
%      the existing singleton*.
%
%      LAB3_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LAB3_GUI.M with the given input arguments.
%
%      LAB3_GUI('Property','Value',...) creates a new LAB3_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lab3_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lab3_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lab3_GUI

% Last Modified by GUIDE v2.5 17-May-2020 17:39:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lab3_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @lab3_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lab3_GUI is made visible.
function lab3_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lab3_GUI (see VARARGIN)

% Choose default command line output for lab3_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
!ssh johan@192.168.1.17
rosinit
global Phantom Posicion P_home Q_home
Phantom=phantom(0,0,0,0);
publicador([0 0 0 0])
Q_home=[0 0 0 0];
MTH_home=Phantom.fkine(Q_home);
R=tr2rpy(MTH_home);
P_home=[MTH_home.t',R];
Posicion=P_home;

% UIWAIT makes lab3_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lab3_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function Home1_Callback(hObject, eventdata, handles)
% hObject    handle to Home1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Home1 as text
%        str2double(get(hObject,'String')) returns contents of Home1 as a double


% --- Executes during object creation, after setting all properties.
function Home1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Home1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Home2_Callback(hObject, eventdata, handles)
% hObject    handle to Home2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Home2 as text
%        str2double(get(hObject,'String')) returns contents of Home2 as a double


% --- Executes during object creation, after setting all properties.
function Home2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Home2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Home3_Callback(hObject, eventdata, handles)
% hObject    handle to Home3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Home3 as text
%        str2double(get(hObject,'String')) returns contents of Home3 as a double


% --- Executes during object creation, after setting all properties.
function Home3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Home3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Home4_Callback(hObject, eventdata, handles)
% hObject    handle to Home4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Home4 as text
%        str2double(get(hObject,'String')) returns contents of Home4 as a double


% --- Executes during object creation, after setting all properties.
function Home4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Home4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ApproachY_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachY as text
%        str2double(get(hObject,'String')) returns contents of ApproachY as a double


% --- Executes during object creation, after setting all properties.
function ApproachY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ApproachZ_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachZ as text
%        str2double(get(hObject,'String')) returns contents of ApproachZ as a double


% --- Executes during object creation, after setting all properties.
function ApproachZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ApproachRoll_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachRoll as text
%        str2double(get(hObject,'String')) returns contents of ApproachRoll as a double


% --- Executes during object creation, after setting all properties.
function ApproachRoll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ActualizarHome.
function ActualizarHome_Callback(hObject, eventdata, handles)
    global Phantom Posicion P_home Q_home
    q1=get(handles.Home1,'String');
    q1=str2double(q1);
    q2=get(handles.Home2,'String');
    q2=str2double(q2);
    q3=get(handles.Home3,'String');
    q3=str2double(q3);
    q4=get(handles.Home4,'String');
    q4=str2double(q4);
    Q_home=[q1 q2 q3 q4];
    publicador(Q_home)
    MTH_home=Phantom.fkine(Q_home);
    R=tr2rpy(MTH_home);
    P_home=[MTH_home.t',R];
    Posicion=P_home;
    
% hObject    handle to ActualizarHome (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ActualizarHome


% --- Executes on button press in RstHome.
function RstHome_Callback(hObject, eventdata, handles)
    global Phantom Posicion P_home Q_home
    Phantom=phantom(0,0,0,0);
    publicador([0 0 0 0])
    Q_home=[0 0 0 0];
    MTH_home=Phantom.fkine(Q_home);
    R=tr2rpy(MTH_home);
    P_home=[MTH_home.t',R];
    Posicion=P_home;
    set(handles.Home1,'String','0')
    set(handles.Home2,'String','0')
    set(handles.Home3,'String','0')
    set(handles.Home4,'String','0')
% hObject    handle to RstHome (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of RstHome


% --- Executes on button press in Comenzar.
function Comenzar_Callback(hObject, eventdata, handles)
global Phantom Posicion Q_home

set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);


%calculando MTH final approach
X_ap=str2double(get(handles.ApproachX,'String'));
Y_ap=str2double(get(handles.ApproachY,'String'));
Z_ap=str2double(get(handles.ApproachZ,'String'));
roll_ap=str2double(get(handles.ApproachRoll,'String'));
pitch_ap=str2double(get(handles.ApproachPitch,'String'));
yaw_ap=str2double(get(handles.ApproachYaw,'String'));
P_ap=[X_ap Y_ap Z_ap roll_ap pitch_ap yaw_ap];

%Moviendo Robot
Approach(Q_home,P_ap,Phantom,15,1)
Posicion=P_ap;

% %Leyendo coordenadas pick
X_pi=str2double(get(handles.PickX,'String'));
Y_pi=str2double(get(handles.PickY,'String'));
Z_pi=str2double(get(handles.PickZ,'String'));
roll_pi=str2double(get(handles.PickRoll,'String'));
pitch_pi=str2double(get(handles.PickPitch,'String'));
yaw_pi=str2double(get(handles.PickYaw,'String'));
P_pi=[X_pi Y_pi Z_pi roll_pi pitch_pi yaw_pi];

% Ejecutando Pick
Pick(P_ap,P_pi,Phantom,6,1)
Posicion=P_ap;

% %Leyendo coordenadas elevate
X_el=str2double(get(handles.ElevX,'String'));
Y_el=str2double(get(handles.ElevY,'String'));
Z_el=str2double(get(handles.ElevZ,'String'));
roll_el=str2double(get(handles.ElevRoll,'String'));
pitch_el=str2double(get(handles.ElevPitch,'String'));
yaw_el=str2double(get(handles.ElevYaw,'String'));
P_el=[X_el Y_el Z_el roll_el pitch_el yaw_el];

% Ejecutando Elevate
Elevate(P_ap,P_el,Phantom,15,1)
Posicion=P_el;

% %Leyendo coordenadas Transport
X_tr=str2double(get(handles.TransX,'String'));
Y_tr=str2double(get(handles.TransY,'String'));
Z_tr=str2double(get(handles.TransZ,'String'));
roll_tr=str2double(get(handles.TransRoll,'String'));
pitch_tr=str2double(get(handles.TransPitch,'String'));
yaw_tr=str2double(get(handles.TransYaw,'String'));
P_tr=[X_tr Y_tr Z_tr roll_tr pitch_tr yaw_tr];

% Ejecutando Transport
Transport(P_el,P_tr,Phantom,15,1)
Posicion=P_tr;

% %Leyendo coordenadas Place
X_pl=str2double(get(handles.PlaceX,'String'));
Y_pl=str2double(get(handles.PlaceY,'String'));
Z_pl=str2double(get(handles.PlaceZ,'String'));
roll_pl=str2double(get(handles.PlaceRoll,'String'));
pitch_pl=str2double(get(handles.PlacePitch,'String'));
yaw_pl=str2double(get(handles.PlaceYaw,'String'));
P_pl=[X_pl Y_pl Z_pl roll_pl pitch_pl yaw_pl];

% Ejecutando Place
Place(P_tr,P_pl,Phantom,6,1)
Posicion=P_tr;

set(handles.Estado,'String','En espera.');
set(handles.Estado,'ForegroundColor',[0 1 0]);





% hObject    handle to Comenzar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Comenzar


% --- Executes on button press in togglebutton4.
function togglebutton4_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton4



function ApproachPitch_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachPitch as text
%        str2double(get(hObject,'String')) returns contents of ApproachPitch as a double


% --- Executes during object creation, after setting all properties.
function ApproachPitch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ApproachYaw_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachYaw as text
%        str2double(get(hObject,'String')) returns contents of ApproachYaw as a double


% --- Executes during object creation, after setting all properties.
function ApproachYaw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ApproachX_Callback(hObject, eventdata, handles)
% hObject    handle to ApproachX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ApproachX as text
%        str2double(get(hObject,'String')) returns contents of ApproachX as a double


% --- Executes during object creation, after setting all properties.
function ApproachX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ApproachX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickY_Callback(hObject, eventdata, handles)
% hObject    handle to PickY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickY as text
%        str2double(get(hObject,'String')) returns contents of PickY as a double


% --- Executes during object creation, after setting all properties.
function PickY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickZ_Callback(hObject, eventdata, handles)
% hObject    handle to PickZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickZ as text
%        str2double(get(hObject,'String')) returns contents of PickZ as a double


% --- Executes during object creation, after setting all properties.
function PickZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickRoll_Callback(hObject, eventdata, handles)
% hObject    handle to PickRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickRoll as text
%        str2double(get(hObject,'String')) returns contents of PickRoll as a double


% --- Executes during object creation, after setting all properties.
function PickRoll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickPitch_Callback(hObject, eventdata, handles)
% hObject    handle to PickPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickPitch as text
%        str2double(get(hObject,'String')) returns contents of PickPitch as a double


% --- Executes during object creation, after setting all properties.
function PickPitch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickYaw_Callback(hObject, eventdata, handles)
% hObject    handle to PickYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickYaw as text
%        str2double(get(hObject,'String')) returns contents of PickYaw as a double


% --- Executes during object creation, after setting all properties.
function PickYaw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PickX_Callback(hObject, eventdata, handles)
% hObject    handle to PickX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PickX as text
%        str2double(get(hObject,'String')) returns contents of PickX as a double


% --- Executes during object creation, after setting all properties.
function PickX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PickX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevY_Callback(hObject, eventdata, handles)
% hObject    handle to ElevY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevY as text
%        str2double(get(hObject,'String')) returns contents of ElevY as a double


% --- Executes during object creation, after setting all properties.
function ElevY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevZ_Callback(hObject, eventdata, handles)
% hObject    handle to ElevZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevZ as text
%        str2double(get(hObject,'String')) returns contents of ElevZ as a double


% --- Executes during object creation, after setting all properties.
function ElevZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevRoll_Callback(hObject, eventdata, handles)
% hObject    handle to ElevRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevRoll as text
%        str2double(get(hObject,'String')) returns contents of ElevRoll as a double


% --- Executes during object creation, after setting all properties.
function ElevRoll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevPitch_Callback(hObject, eventdata, handles)
% hObject    handle to ElevPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevPitch as text
%        str2double(get(hObject,'String')) returns contents of ElevPitch as a double


% --- Executes during object creation, after setting all properties.
function ElevPitch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevYaw_Callback(hObject, eventdata, handles)
% hObject    handle to ElevYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevYaw as text
%        str2double(get(hObject,'String')) returns contents of ElevYaw as a double


% --- Executes during object creation, after setting all properties.
function ElevYaw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ElevX_Callback(hObject, eventdata, handles)
% hObject    handle to ElevX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevX as text
%        str2double(get(hObject,'String')) returns contents of ElevX as a double


% --- Executes during object creation, after setting all properties.
function ElevX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransY_Callback(hObject, eventdata, handles)
% hObject    handle to TransY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransY as text
%        str2double(get(hObject,'String')) returns contents of TransY as a double


% --- Executes during object creation, after setting all properties.
function TransY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransZ_Callback(hObject, eventdata, handles)
% hObject    handle to TransZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransZ as text
%        str2double(get(hObject,'String')) returns contents of TransZ as a double


% --- Executes during object creation, after setting all properties.
function TransZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransRoll_Callback(hObject, eventdata, handles)
% hObject    handle to TransRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransRoll as text
%        str2double(get(hObject,'String')) returns contents of TransRoll as a double


% --- Executes during object creation, after setting all properties.
function TransRoll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransPitch_Callback(hObject, eventdata, handles)
% hObject    handle to TransPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransPitch as text
%        str2double(get(hObject,'String')) returns contents of TransPitch as a double


% --- Executes during object creation, after setting all properties.
function TransPitch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransPitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransYaw_Callback(hObject, eventdata, handles)
% hObject    handle to TransYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransYaw as text
%        str2double(get(hObject,'String')) returns contents of TransYaw as a double


% --- Executes during object creation, after setting all properties.
function TransYaw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TransX_Callback(hObject, eventdata, handles)
% hObject    handle to TransX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TransX as text
%        str2double(get(hObject,'String')) returns contents of TransX as a double


% --- Executes during object creation, after setting all properties.
function TransX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TransX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlaceY_Callback(hObject, eventdata, handles)
% hObject    handle to PlaceY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlaceY as text
%        str2double(get(hObject,'String')) returns contents of PlaceY as a double


% --- Executes during object creation, after setting all properties.
function PlaceY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlaceY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlaceZ_Callback(hObject, eventdata, handles)
% hObject    handle to PlaceZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlaceZ as text
%        str2double(get(hObject,'String')) returns contents of PlaceZ as a double


% --- Executes during object creation, after setting all properties.
function PlaceZ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlaceZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlaceRoll_Callback(hObject, eventdata, handles)
% hObject    handle to PlaceRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlaceRoll as text
%        str2double(get(hObject,'String')) returns contents of PlaceRoll as a double


% --- Executes during object creation, after setting all properties.
function PlaceRoll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlaceRoll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlacePitch_Callback(hObject, eventdata, handles)
% hObject    handle to PlacePitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlacePitch as text
%        str2double(get(hObject,'String')) returns contents of PlacePitch as a double


% --- Executes during object creation, after setting all properties.
function PlacePitch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlacePitch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlaceYaw_Callback(hObject, eventdata, handles)
% hObject    handle to PlaceYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlaceYaw as text
%        str2double(get(hObject,'String')) returns contents of PlaceYaw as a double


% --- Executes during object creation, after setting all properties.
function PlaceYaw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlaceYaw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PlaceX_Callback(hObject, eventdata, handles)
% hObject    handle to PlaceX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PlaceX as text
%        str2double(get(hObject,'String')) returns contents of PlaceX as a double


% --- Executes during object creation, after setting all properties.
function PlaceX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PlaceX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton5.
function togglebutton5_Callback(hObject, eventdata, handles)
global Posicion Phantom Q_home
set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);

T=Posicion(1:3)';
R=rpy2r(Posicion(4:6));
MTHi=rt2tr(R,T);
MTHf=Phantom.fkine(Q_home);
mover_phantom(MTHi,MTHf,15,Phantom)

set(handles.Estado,'String','En espera.');
set(handles.Estado,'ForegroundColor',[0 1 0]);
% hObject    handle to togglebutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton5


% --- Executes on button press in ExtAp.
function ExtAp_Callback(hObject, eventdata, handles)
global Phantom Posicion Q_home

set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);
% Leyendo posicion de home

%calculando MTH final approach
X_ap=str2double(get(handles.ApproachX,'String'));
Y_ap=str2double(get(handles.ApproachY,'String'));
Z_ap=str2double(get(handles.ApproachZ,'String'));
roll_ap=str2double(get(handles.ApproachRoll,'String'));
pitch_ap=str2double(get(handles.ApproachPitch,'String'));
yaw_ap=str2double(get(handles.ApproachYaw,'String'));
P_ap=[X_ap Y_ap Z_ap roll_ap pitch_ap yaw_ap];

%Moviendo Robot
Approach(Q_home,P_ap,Phantom,15,1)
Posicion=P_ap;

set(handles.Estado,'String','En espera');
set(handles.Estado,'ForegroundColor',[0 1 0]);
% hObject    handle to ExtAp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ExtAp


% --- Executes on button press in ExtPi.
function ExtPi_Callback(hObject, eventdata, handles)
global Phantom Posicion
set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);

%calculando MTH final approach
X_ap=str2double(get(handles.ApproachX,'String'));
Y_ap=str2double(get(handles.ApproachY,'String'));
Z_ap=str2double(get(handles.ApproachZ,'String'));
roll_ap=str2double(get(handles.ApproachRoll,'String'));
pitch_ap=str2double(get(handles.ApproachPitch,'String'));
yaw_ap=str2double(get(handles.ApproachYaw,'String'));
P_ap=[X_ap Y_ap Z_ap roll_ap pitch_ap yaw_ap];

% %Leyendo coordenadas pick
X_pi=str2double(get(handles.PickX,'String'));
Y_pi=str2double(get(handles.PickY,'String'));
Z_pi=str2double(get(handles.PickZ,'String'));
roll_pi=str2double(get(handles.PickRoll,'String'));
pitch_pi=str2double(get(handles.PickPitch,'String'));
yaw_pi=str2double(get(handles.PickYaw,'String'));
P_pi=[X_pi Y_pi Z_pi roll_pi pitch_pi yaw_pi];

% Ejecutando Pick
Pick(P_ap,P_pi,Phantom,6,1)
Posicion=P_ap;

set(handles.Estado,'String','En Espera');
set(handles.Estado,'ForegroundColor',[0 1 0]);
% hObject    handle to ExtPi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ExtPi


% --- Executes on button press in ExtEl.
function ExtEl_Callback(hObject, eventdata, handles)
global Phantom Posicion
set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);

%calculando MTH final approach
X_ap=str2double(get(handles.ApproachX,'String'));
Y_ap=str2double(get(handles.ApproachY,'String'));
Z_ap=str2double(get(handles.ApproachZ,'String'));
roll_ap=str2double(get(handles.ApproachRoll,'String'));
pitch_ap=str2double(get(handles.ApproachPitch,'String'));
yaw_ap=str2double(get(handles.ApproachYaw,'String'));
P_ap=[X_ap Y_ap Z_ap roll_ap pitch_ap yaw_ap];

% %Leyendo coordenadas elevate
X_el=str2double(get(handles.ElevX,'String'));
Y_el=str2double(get(handles.ElevY,'String'));
Z_el=str2double(get(handles.ElevZ,'String'));
roll_el=str2double(get(handles.ElevRoll,'String'));
pitch_el=str2double(get(handles.ElevPitch,'String'));
yaw_el=str2double(get(handles.ElevYaw,'String'));
P_el=[X_el Y_el Z_el roll_el pitch_el yaw_el];

% Ejecutando Elevate
Elevate(P_ap,P_el,Phantom,15,1)
Posicion=P_el;

set(handles.Estado,'String','En espera.');
set(handles.Estado,'ForegroundColor',[0 1 0]);

% hObject    handle to ExtEl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ExtEl


% --- Executes on button press in ExtTr.
function ExtTr_Callback(hObject, eventdata, handles)
global Phantom Posicion
set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);

% %Leyendo coordenadas elevate
X_el=str2double(get(handles.ElevX,'String'));
Y_el=str2double(get(handles.ElevY,'String'));
Z_el=str2double(get(handles.ElevZ,'String'));
roll_el=str2double(get(handles.ElevRoll,'String'));
pitch_el=str2double(get(handles.ElevPitch,'String'));
yaw_el=str2double(get(handles.ElevYaw,'String'));
P_el=[X_el Y_el Z_el roll_el pitch_el yaw_el];

% %Leyendo coordenadas Transport
X_tr=str2double(get(handles.TransX,'String'));
Y_tr=str2double(get(handles.TransY,'String'));
Z_tr=str2double(get(handles.TransZ,'String'));
roll_tr=str2double(get(handles.TransRoll,'String'));
pitch_tr=str2double(get(handles.TransPitch,'String'));
yaw_tr=str2double(get(handles.TransYaw,'String'));
P_tr=[X_tr Y_tr Z_tr roll_tr pitch_tr yaw_tr];

% Ejecutando Transport
Transport(P_el,P_tr,Phantom,15,1)
Posicion=P_tr;

set(handles.Estado,'String','En espera.');
set(handles.Estado,'ForegroundColor',[0 1 0]);
% hObject    handle to ExtTr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ExtTr


% --- Executes on button press in ExtPl.
function ExtPl_Callback(hObject, eventdata, handles)
global Phantom Posicion
set(handles.Estado,'String','Ocupado');
set(handles.Estado,'ForegroundColor',[1 0 0]);

% %Leyendo coordenadas Transport
X_tr=str2double(get(handles.TransX,'String'));
Y_tr=str2double(get(handles.TransY,'String'));
Z_tr=str2double(get(handles.TransZ,'String'));
roll_tr=str2double(get(handles.TransRoll,'String'));
pitch_tr=str2double(get(handles.TransPitch,'String'));
yaw_tr=str2double(get(handles.TransYaw,'String'));
P_tr=[X_tr Y_tr Z_tr roll_tr pitch_tr yaw_tr];

% %Leyendo coordenadas Place
X_pl=str2double(get(handles.PlaceX,'String'));
Y_pl=str2double(get(handles.PlaceY,'String'));
Z_pl=str2double(get(handles.PlaceZ,'String'));
roll_pl=str2double(get(handles.PlaceRoll,'String'));
pitch_pl=str2double(get(handles.PlacePitch,'String'));
yaw_pl=str2double(get(handles.PlaceYaw,'String'));
P_pl=[X_pl Y_pl Z_pl roll_pl pitch_pl yaw_pl];

% Ejecutando Place
Place(P_tr,P_pl,Phantom,6,1)
Posicion=P_tr;

set(handles.Estado,'String','En espera.');
set(handles.Estado,'ForegroundColor',[0 1 0]);
% hObject    handle to ExtPl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ExtPl
