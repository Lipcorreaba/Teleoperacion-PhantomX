function Posicion=mover(MTHi,MTHf,puntos,Robot,x,y,z,r,p,ya,con)
    Qi=Robot.ikunc(MTHi);
    Qf=Robot.ikunc(MTHf);
    paso=(Qf-Qi)/puntos;
    Q=Qi;
    for i=0:puntos
        publicador(Q)
        pause(0.5)
        t=Robot.fkine(Q);
        Qg=round(Q*180/pi,3);
        set(con,'String','['+string(vpa(Qg(1),3))+' '+string(vpa(Qg(2),3))+' '+string(vpa(Qg(3),3))+' '+string(vpa(Qg(4),3))+']');
        Posicion=round([t.t',tr2rpy(t)],3);
        set(x,'String',string(vpa(Posicion(1),3)));
        set(y,'String',string(vpa(Posicion(2),3)));
        set(z,'String',string(vpa(Posicion(3),3)));
        set(r,'String',string(vpa(Posicion(4),3)));
        set(p,'String',string(vpa(Posicion(5),3)));
        set(ya,'String',string(vpa(Posicion(6),3)));
        Q=Q+paso;
    end    
end