function terminateInCode()

hFig = figure('CloseRequestFcn',{@closeHandler});

stop=0;
while(~stop)
   plot(10*rand,10*rand,'+');
   pause(0.1);
end;

   function closeHandler (src,evnt)
      delete(hFig);
      stop=1;
   end
end