function Place(Pi_pl,Pf_pl,Robot,puntos,x,y,z,r,p,ya,con)
    Ti_pl=Pi_pl(1:3)';
    Ri_pl=rpy2r(Pi_pl(4:6));
    MTHi_pl=rt2tr(Ri_pl,Ti_pl);
    Tf_pl=Pf_pl(1:3)';
    Rf_pl=rpy2r(Pf_pl(4:6));
    MTHf_pl=rt2tr(Rf_pl,Tf_pl);
    pp_phantom(MTHi_pl,MTHf_pl,puntos,Robot,x,y,z,r,p,ya,con)
    gripper('abrir')
    pause(0.5)
    pp_phantom(MTHf_pl,MTHi_pl,puntos,Robot,x,y,z,r,p,ya,con)
end